# Loopback-Mysql
Menghubungkan antara Loopback dengan Mysql
