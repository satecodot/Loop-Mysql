'use strict';

module.exports = function(Karyawan) {

};
