'use strict';

module.exports = function(Pedagang) {

};
